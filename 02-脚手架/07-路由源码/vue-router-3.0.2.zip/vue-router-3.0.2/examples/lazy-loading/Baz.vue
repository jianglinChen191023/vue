<template>
  <div>
    <h3>Baz</h3>
    <p>I'm loaded in the same chunk with Bar.</p>
  </div>
</template>
